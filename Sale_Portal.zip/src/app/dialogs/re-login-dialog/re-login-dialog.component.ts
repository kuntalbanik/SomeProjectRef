import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { LoginRegistrationService } from 'src/app/login/service/login-registration.service';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { FormControl, Validators } from '@angular/forms';
import { CustomValidators } from 'src/app/shared/custom.validator';
import { LoaderService } from 'src/app/service/loader.service';
import { UserDetailsService } from 'src/app/service/user-details/user-details.service';

@Component({
  selector: 'app-re-login-dialog',
  templateUrl: './re-login-dialog.component.html',
  styleUrls: ['./re-login-dialog.component.css']
})
export class ReLoginDialogComponent implements OnInit, OnDestroy {
  passwordMinLength: number = 8;
  password: any = '';
  logInError: string = "";
  unsubscribeSubscription$: Subject<boolean> = new Subject<boolean>();

  constructor(
    public dialogRef: MatDialogRef<ReLoginDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private loginRegistrationService: LoginRegistrationService,
    private loaderService: LoaderService,
    private userDetailsService: UserDetailsService,

  ) { }

  ngOnInit(): void {
    this.password = new FormControl('', [Validators.required, Validators.minLength(this.passwordMinLength), CustomValidators.passwordPatternCheck()])
  }
  ngOnDestroy(): void {
    this.unsubscribeSubscription$.next(true);
    this.unsubscribeSubscription$.unsubscribe();
  }

  logIn = () => {
    this.logInError = "";
    let userDetails = {
      emailId: this.data.emailId,
      password: this.password.value
    };
    this.loginRegistrationService.logInAuthentication(userDetails)
      .pipe(takeUntil(this.unsubscribeSubscription$))
      .subscribe((data) => {
        console.log(data);
        if (data["success"]) {
          this.dialogRef.close(data)
        }
      },
        (error) => {
          console.log(error);
          if (error.non_field_errors == undefined || error.non_field_errors.length == 0) {
            this.logInError = "Network issue please try again later";
          } else {
            switch (error.non_field_errors[0]) {
              case 'login error': this.logInError = "Password is not correct"; break;
              case 'max tokens':
                this.logInError = "Maximum login exceeds";
                let token = error.token[0];
                if (confirm("Maximum Login Exceeds\nLogout all other logins and proceed with this login?")) this.logoutAllAndLogin(token);
                break;
              default: this.logInError = "Network issue please try again later"
            }
          }
        }
      );
  }

  confirmClose = () => {
    if (confirm("All unsaved data will be lost, are you sure you want to exit?"))
      this.dialogRef.close('cancelled');
  }

  logoutAllAndLogin = (token) => {
    this.loaderService.display(true);
    this.userDetailsService.logoutAll(token)
    .pipe(takeUntil(this.unsubscribeSubscription$))
    .subscribe(
      (data) => {
        if (data == null) this.logIn();
        else this.logInError = "Network issue please try again later";
      },
      (error) => {
        this.logInError = "Network issue please try again later";
      }
    );
  }

}

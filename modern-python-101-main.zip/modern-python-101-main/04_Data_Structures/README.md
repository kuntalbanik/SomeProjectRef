# Data Structures

Topics Covered -

1. List, List Comprehensions
2. Tuple
3. Dictionary
4. Set

## Sequence

1. friends.py - List
2. subjects.py - Tuple
3. marks.py - Dictionary
4. Dictionary.md - Extra Reading
5. teach.py - Set
6. game_save_zortan_2.py

## Extra

7. choices.py - Enum
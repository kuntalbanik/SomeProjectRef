import { Component, OnInit, OnDestroy } from '@angular/core';
import { UserDetailsService } from '../service/user-details/user-details.service';
import { Router } from '@angular/router';
import { Observable, Subject } from 'rxjs';
import { LoaderService } from '../service/loader.service';
import { takeUntil } from 'rxjs/operators';

import { MatDialog } from '@angular/material/dialog';
import { ReLoginDialogComponent } from '../dialogs/re-login-dialog/re-login-dialog.component';
import { ChangePasswordDialogComponent } from '../dialogs/change-password-dialog/change-password-dialog.component';
import { OnlyTextDialogComponent } from 'src/app/dialogs/only-text-dialog/only-text-dialog.component';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit, OnDestroy {

  loggedInUserDetails$: Observable<any> = this.userDetailsService.getLoggedInUserDetails();
  sessionTimedout: boolean = this.userDetailsService.sessionTimedout;
  unsubscribeSubscription$: Subject<boolean> = new Subject<boolean>();
  userDetails: any = {};
  navBarColorClass: string = "";
  iconColorClass: string = "";
  backendError: string = "";

  constructor(
    private userDetailsService: UserDetailsService,
    private loaderService: LoaderService,
    public router: Router,
    public reLoginDialog: MatDialog,
    public changePasswordDialog: MatDialog,
    public onlyTextDialog: MatDialog,
  ) {

  }

  ngOnInit() {
    if (this.sessionTimedout) this.openReLoginDialog();
    console.log("Admin Dashboard")
  }
  ngOnDestroy(): void {
    this.unsubscribeSubscription$.next(true);
    this.unsubscribeSubscription$.unsubscribe();
  }

  setUserDetails = (userDetails) => {
    console.log(userDetails)
    this.userDetails = userDetails;
    switch (userDetails.role) {
      case "manager": 
        this.navBarColorClass = "bg-orange1 fg-white1";
        this.iconColorClass = "fg-orange1";
        break;
      case "super-admin":
        this.navBarColorClass = "bg-teal1 fg-white1";
        this.iconColorClass = "fg-teal1";
        break;
      case "channel-partner": 
        this.navBarColorClass = "bg-purple1 fg-white1";
        this.iconColorClass = "fg-purple1";
        break;
      case "user": 
        this.navBarColorClass = "bg-lightblue1 fg-white1";
        this.iconColorClass = "fg-lightblue1";
        break;
      default: 
        this.navBarColorClass = "bg-lightblue1 fg-white1";
        this.navBarColorClass = "fg-lightblue1";
    }
  }

  logout() {
    this.loaderService.display(true);
    this.userDetailsService.logoutUser()
      .pipe(takeUntil(this.unsubscribeSubscription$))
      .subscribe(
        (res) => {
          if (res == null) {
            this.router.navigate(['login']);
          } else {
            this.backendError = "Network issue please try again later";
          }
        },
        (error) => {
          this.backendError = "Network issue please try again later";
        }
      );
  }

  logoutAll = () => {
    this.loaderService.display(true);
    this.userDetailsService.logoutAll()
    .pipe(takeUntil(this.unsubscribeSubscription$))
    .subscribe(
      (data) => {
        if (data == null) this.router.navigate(['login']);
        else this.backendError = "Network issue please try again later";
      },
      (error) => {
        this.backendError = "Network issue please try again later";
      }
    );
  }


  openReLoginDialog = () => {
    const unsubscribeDialog$ = new Subject();
    const dialogRef = this.reLoginDialog.open(ReLoginDialogComponent, {
      disableClose: true,
      data: { emailId: this.userDetailsService.userEmailId, userName: this.userDetailsService.userName }
    });

    dialogRef.afterClosed().pipe(
      takeUntil(unsubscribeDialog$)
    ).subscribe(result => {
      console.log(result);
      if (result != "cancelled") {
        let urlRole = this.router.url.split('/')[2] || '';
        let url = (urlRole == this.userDetails.role) ? this.router.url : result.res;
        this.router.navigate([url]);
      } else {
        this.router.navigate(['']);
      }
      unsubscribeDialog$.next(true);
      unsubscribeDialog$.unsubscribe();
    });
  }

  openChangePasswordDialog = () => {
    const unsubscribeDialog$ = new Subject();
    const dialogRef = this.changePasswordDialog.open(ChangePasswordDialogComponent, {
      disableClose: true,
    });

    dialogRef.afterClosed().pipe(
      takeUntil(unsubscribeDialog$)
    ).subscribe(result => {
      if(result === 'success') this.openOnlyTextDialog('Password Changed Successfully');
      unsubscribeDialog$.next(true);
      unsubscribeDialog$.unsubscribe();
    });
  }

  openOnlyTextDialog = (msg) => {
    const unsubscribeDialog$ = new Subject();
    const dialogRef = this.onlyTextDialog.open(OnlyTextDialogComponent, {
      data: { msg: msg }
    });

    dialogRef.afterClosed().pipe(
      takeUntil(unsubscribeDialog$)
    ).subscribe(result => {
      unsubscribeDialog$.next(true);
      unsubscribeDialog$.unsubscribe();
    });
  }

}

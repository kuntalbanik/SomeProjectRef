import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, tap, map, takeUntil, first } from 'rxjs/operators';
import { throwError, of, Subject, BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserDetailsService {

  loggedInUserDetails: BehaviorSubject<any> = new BehaviorSubject<any>(null);
  userName: string = "";
  userEmailId: string = "";
  userRole: string = "";
  loggedInToken: string = "";
  tokenTimeout: any = null;
  isValidToken = false;
  tokenValidity: number = 0;
  logInStatus: Subject<boolean> = new Subject<boolean>();
  sessionTimedout: boolean = false;
  unsubscribeLogout: Subject<any> = new Subject<any>();
  apiLink = {
    logOut: "https://accountp.herokuapp.com/api/auth/logout/",
    logOutAll: "https://accountp.herokuapp.com/api/auth/logoutall/",
    userDetails: "https://accountp.herokuapp.com/api/auth/user/",
    changePassword: "https://accountp.herokuapp.com/api/auth/user/password/"
  };

  constructor(
    private http: HttpClient
  ) {
  }

  setLoggedinUserDerails = (userDetails) => {
    if (!this.sessionTimedout) {
      this.userName = userDetails == null ? '' : userDetails.fullName;
      this.userEmailId = userDetails == null ? '' : userDetails.emailId;
    }
    userDetails.role = userDetails.role.length === 0 ? 'user': userDetails.role;
    this.userRole = userDetails == null ? '' : userDetails.role;
    this.loggedInUserDetails.next(userDetails);
  };
  getLogInStatus = () => {
    return this.logInStatus.asObservable();
  }

  setLoggedInTokenDetails = (token, validity) => {
    this.loggedInToken = token;
    this.tokenValidity = validity;
    this.isValidToken = true;
    this.sessionTimedout = false;
    clearTimeout(this.tokenTimeout);
    this.tokenTimeout = setTimeout(() => {
      this.isValidToken = false;
      this.sessionTimedout = true;
    }, this.tokenValidity);
  };

  validateToken = () => {
    this.loggedInToken = (this.loggedInToken == null || this.loggedInToken.length == 0)
      ? localStorage.getItem('token') : this.loggedInToken;
    let user = JSON.parse(localStorage.getItem('user'));
    this.userName = (user == null || user == "null") ? '' : user.name;
    this.userEmailId = (user == null || user == "null") ? '' : user.emailId;
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    let res = {
      valid: false,
      timedout: false,
      role: ''
    };
    if (this.loggedInToken == null ||
      this.loggedInToken == "null" ||
      this.loggedInToken.length == 0) {
      return of(res);
    }
    const apiLink = this.apiLink["userDetails"];
    const options = {
      headers: new HttpHeaders({
        'Authorization': 'Token ' + this.loggedInToken
      })
    };
    return this.http.get(apiLink, options).pipe(
      map((data) => {
        if (!this.isEmpty(data)) {
          res.valid = true;
          res.role = data["userData"].role || 'user';
          this.setLoggedInTokenDetails(this.loggedInToken, this.tokenValidity);
          this.setLoggedinUserDerails(data["userData"]);
        } else {
          this.resetLoggedInUserDetails();
        }
        return res;
      }),
      catchError((error) => {
        res.valid = false;
        res.timedout = true;
        this.sessionTimedout = true;
        this.resetLoggedInUserDetails();
        return of(res)
      })
    );
  }

  getLoggedInUserDetails = () => {
    return this.loggedInUserDetails.asObservable();
  }

  setLoggedInTokenToStorage = () => {
    localStorage.setItem("token", this.loggedInToken);
    localStorage.setItem("user", JSON.stringify({ name: this.userName, emailId: this.userEmailId }));
  }

  resetLoggedInUserDetails = () => {
    this.loggedInToken = "";
    clearTimeout(this.tokenTimeout);
    this.tokenValidity = 0;
    this.isValidToken = false;
    this.setLoggedinUserDerails(null);
  }

  logoutUser = () => {
    const apiLink = this.apiLink["logOut"];
    const options = {
      headers: new HttpHeaders({
        'Authorization': 'Token ' + this.loggedInToken
      })
    };
    return this.http.post(apiLink, {}, options).pipe(
      tap(() => {
        this.resetLoggedInUserDetails();
      }),
      catchError((error) => {
        console.log(error)
        this.resetLoggedInUserDetails();
        return throwError("Network issue, please try after sometime")
      }),
    )
  }

  logoutAll = (token = this.loggedInToken) => {
    const apiLink = this.apiLink["logOutAll"];
    const options = {
      headers: new HttpHeaders({
        'Authorization': 'Token ' + token
      })
    };
    return this.http.post(apiLink, {}, options).pipe(
      tap(() => {
        this.resetLoggedInUserDetails();
      }),
      catchError((error) => {
        console.log(error)
        this.resetLoggedInUserDetails();
        return throwError("Network issue, please try after sometime")
      }),
    )
  };

  changePassword = (currentPassword, newPassword) => {
    if(newPassword.length == 0) return null;

    const apiLink = this.apiLink["changePassword"];
    const options = {
      headers: new HttpHeaders({
        'Authorization': 'Token ' + this.loggedInToken
      })
    };
    return this.http.put(apiLink, {old_password: currentPassword, new_password: newPassword}, options);
  }


  isEmpty = (obj) => {
    for (var x in obj) { return false; }
    return true;
  }

}

import { Injectable } from '@angular/core';
import { Router, Route, ActivatedRouteSnapshot, RouterStateSnapshot, CanLoad, CanActivate } from '@angular/router';
import { catchError, map} from 'rxjs/operators';
import { Subject, Observable, throwError, of } from 'rxjs';
import { UserDetailsService } from './user-details/user-details.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardService implements CanActivate {

  destroyLogInStatusSubscription = new Subject();
  activateResponse = false;

  constructor(private router: Router, private userDetailsService: UserDetailsService) {
  }

  canActivate(activatedRoute: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    let url = state.url;
    let urlRole = url.split('/')[2] || '';
    let userRole = this.userDetailsService.userRole;
    if (this.userDetailsService.isValidToken) {
      return of(this.navigateByRole(urlRole, userRole));
    }
    return this.userDetailsService.validateToken().pipe(
      map((data) => {
        console.log(url)
        console.log(data)
        return this.navigateByToken(data["valid"], data["timedout"], data["role"], url, urlRole);
      }),
      catchError((error) => {
        this.router.navigate(['login']);
        return of(false);
      })
    );
  }

  navigateByToken = (status, timedOut, role, url, urlRole) => {
    let res = false;
    if (status) {
      if (url == "/login") {
        this.router.navigate([`/dashboard/${role}`]);
      } else {
        return this.navigateByRole(urlRole, role);
      }
    } else if(timedOut){
      res = true;
    } else if (url == "/login") {
      res = true;
    } else {
      this.router.navigate(['login']);
    }
    console.log(res)
    return res;
  }

  navigateByRole = (urlRole, userRole) => {
    if (urlRole.trim() == userRole.trim()) return true;
    this.router.navigate([`/dashboard/${userRole}`]);
    return false;
  }

}

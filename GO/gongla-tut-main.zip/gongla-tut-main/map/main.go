package main

import "fmt"

func main() {

	// Normal variable type
	//
	// var colors map[string]string

	//
	// Simple way - Object like

	colors := map[string]string{
		"red":   "#ff0000",
		"green": "#4bff78",
		"white": "#ffffff",
		"black": "#000000",
	}

	//
	// Professional type

	// colors := make(map[int]string)

	// Define value
	// colors[10] = "#ffffff"

	// Edit / Update value
	// colors[10] = "#ff0066"

	// Delete value
	// delete(colors, 10)

	// fmt.Println(printMap(colors))
	// fmt.Println(colors)
	printMap(colors)
}

// Iterate over map
// ...
func printMap(c map[string]string) {
	// c = map[string]string{
	// 	"red":   "#555555",
	// 	"green": "#555555",
	// 	"white": "#555555",
	// 	"black": "#555555",
	// }
	for color, hex := range c {
		fmt.Println("Hex code for", color, "is", hex)
	}
	// return c
}

package main

import "fmt"

func main() {

	user := map[string]int{
		"age": 42,
	}

	fmt.Println(user["age"])

	user2 := map[string]string{
		"name":    "Kuntal",
		"country": "India",
	}
	fmt.Println(user2)
	//
	// Insert / Update / Delete
	//
	scores := make(map[string]int)

	scores["math"] = 90    // add
	scores["math"] = 95    // update
	delete(scores, "math") // delete

	//
	// Check value exists or not
	//
	m := map[string]int{
		"a": 1,
	}

	v, ok := m["b"]

	fmt.Println(v)  // 0
	fmt.Println(ok) // false

	// 	গোল্ডেন রুল ⭐
	// 🧠 map থেকে value নিলে সবসময় ok check করো
	// বিশেষ করে:

	// payment
	// auth
	// config
	// feature flag
}

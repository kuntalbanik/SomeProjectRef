"""
Primitive Data Types in Python
--------------------------------

1. Strings - "Louis"
2. Integers - 45
3. Floats - 3.14
4. Boolean - True/False
"""

my_string = "Louis"
my_int = 45
my_float = 3.14
my_bool = True

print(my_string)
print(my_int)
print(my_float)
print(my_bool)

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-channel-partner-dashboard',
  templateUrl: './channel-partner-dashboard.component.html',
  styleUrls: ['./channel-partner-dashboard.component.css']
})
export class ChannelPartnerDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

# Projects

We have two projects and overthought they look simple, they are densely packed with concepts and it may require you to go through them multiple times to fully understand them.

1. Cash Register
2. Game - Save Zortan
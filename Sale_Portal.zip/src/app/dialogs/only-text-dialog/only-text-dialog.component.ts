import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-only-text-dialog',
  templateUrl: './only-text-dialog.component.html',
  styleUrls: ['./only-text-dialog.component.css']
})
export class OnlyTextDialogComponent implements OnInit {

  constructor(
    public dialogRef: MatDialogRef<OnlyTextDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { }

  ngOnInit() {
  }

}

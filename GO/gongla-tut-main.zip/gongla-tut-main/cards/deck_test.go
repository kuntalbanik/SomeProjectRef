package main

import (
	"os"
	"testing"
)

func TestNewDeck(t *testing.T) {
	// t is testing handler
	d := newDeck()
	deckLength := 16

	if len(d) != deckLength {
		t.Errorf("Expected deck length of %v, but got %v", deckLength, len(d))
	}

	if d[0] != "Ace of Spades" {
		t.Errorf("Expected first card is 'Ace of Spades', but got %v", d[0])
	}

	if d[len(d)-1] != "Four of Clubs" {
		t.Errorf("Expected last card is 'Four of Clubs', but got %v", d[len(d)-1])
	}
}

func TestSaveToDeckAndNewDeckFromFile(t *testing.T) {
	os.Remove("_decktesting")
	deckLength := 16

	deck := newDeck()
	deck.saveToFile("_decktesting")

	loadedDeck := newDeckFromFile("_decktesting")

	if len(loadedDeck) != deckLength {
		t.Errorf("Expected deck length of %v, but got %v", deckLength, len(loadedDeck))
	}

	os.Remove("_decktesting")
}

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdminDashboardComponent } from './admin-dashboard.component';

const routes: Routes = [
  {
    path: '', 
    component: AdminDashboardComponent,
    children: [
      // { path: '', redirectTo: 'dashboard/', pathMatch: "full" },
      {
        path: 'manager',
        loadChildren: () => import('../manager/manager.module').then(m => m.ManagerModule),
      },
      {
        path: 'super-admin',
        loadChildren: () => import('../super-admin/super-admin.module').then(m => m.SuperAdminModule)
      },
      {
        path: 'channel-partner',
        loadChildren: () => import('../channel-partner/channel-partner.module').then(m => m.ChannelPartnerModule)
      },
      {
        path: 'user',
        loadChildren: () => import('../user/user.module').then(m => m.UserModule),
      },
    ],
  },  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminDashboardRoutingModule { }

package main

import "fmt"

type names []string

// Normal function
// receive parameter
func printName(n names) {
	for i, name := range n {
		fmt.Println(i, name)
	}
}

// Receiver function
// ...
func (n names) printName() {
	for i, name := range n {
		fmt.Println(i, name)
	}
}

// func main() {
// 	friends := names{"John", "Jane", "Rone"}

// 	// Without receiver function
// 	printName(friends)

// 	// With using receiver function
// 	friends.printName()

// 	names.printName(friends)
// }

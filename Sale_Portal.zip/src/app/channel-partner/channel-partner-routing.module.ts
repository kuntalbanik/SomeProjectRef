import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ChannelPartnerDashboardComponent } from './channel-partner-dashboard/channel-partner-dashboard.component';


const routes: Routes = [
  {
    path: '', 
    component: ChannelPartnerDashboardComponent,
  },  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ChannelPartnerRoutingModule { }

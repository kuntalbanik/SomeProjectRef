import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserRoutingModule } from './user-routing.module';
import {MatCardModule} from '@angular/material/card';
import { SharedMaterialModule } from '../shared/shared-material.module';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';


@NgModule({
  declarations: [UserDashboardComponent],
  imports: [
    CommonModule,
    UserRoutingModule,
    SharedMaterialModule,
    MatCardModule
  ]
})
export class UserModule { }

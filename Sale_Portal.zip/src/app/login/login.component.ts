import { Component, OnInit, ChangeDetectorRef, HostListener, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CustomValidators } from '../shared/custom.validator';
import { LoginRegistrationService } from './service/login-registration.service';
import { Router } from '@angular/router';
import { Observable, Subject } from 'rxjs';
import { LoaderService } from '../service/loader.service';
import { takeUntil } from 'rxjs/operators';
import { UserDetailsService } from '../service/user-details/user-details.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit, OnDestroy {

  loginForm: FormGroup;
  logInError: string;
  unsubscribeSubscription$: Subject<boolean> = new Subject<boolean>();

  constructor(
    private fb: FormBuilder,
    private loginRegistrationService: LoginRegistrationService,
    private userDetailsService: UserDetailsService,
    public router: Router,
    private loaderService: LoaderService
  ) {
  }

  ngOnInit() {
    this.loginForm = this.fb.group({
      emailId: ['', [Validators.required, CustomValidators.emailOrPhoneNumber('emailId')]],
      password: ['', [Validators.required, CustomValidators.passwordPatternCheck()]]
    });
  }

  ngOnDestroy(): void {
    this.unsubscribeSubscription$.next(true);
    this.unsubscribeSubscription$.unsubscribe();
  }

  get emailId() {
    return this.loginForm.get('emailId');
  }
  get password() {
    return this.loginForm.get('password');
  }

  submitLogin() {
    if (this.loginForm.valid) {
      this.logInError = "";
      this.loaderService.display(true);
      this.loginRegistrationService.logInAuthentication(this.loginForm.value)
        .pipe(takeUntil(this.unsubscribeSubscription$))
        .subscribe(
          (data) => {
            console.log(data)
            if (data["success"]) {
              this.router.navigate([data.res]);
            }
          },
          (error) => {
            console.log(error);
            if (error.non_field_errors == undefined || error.non_field_errors.length == 0) {
              this.logInError = "Network issue please try again later";
            } else {
              switch (error.non_field_errors[0]) {
                case 'login error': this.logInError = "Email ID/Password is not correct"; break;
                case 'max tokens':
                  this.logInError = "Maximum login exceeds";
                  let token = error.token[0];
                  if(confirm("Maximum Login Exceeds\nLogout all other logins and proceed with this login?")) this.logoutAllAndLogin(token);                  
                  break;
                default: this.logInError = "Network issue please try again later";
              }
            }
          }
        );
    }
  }

  logoutAllAndLogin = (token) => {
    this.loaderService.display(true);
    this.userDetailsService.logoutAll(token)
    .pipe(takeUntil(this.unsubscribeSubscription$))
    .subscribe(
      (data) => {
        if (data == null) this.submitLogin();
        else this.logInError = "Network issue please try again later";
      },
      (error) => {
        this.logInError = "Network issue please try again later";
      }
    );
  }

}

"""
Now that Louis is in Zortan, he has to do things differently.
Zortan 🪐 people spell their name with each character on different line.
"""

name: str = "Louis"

# Create a `For` loop to iterate over the characters in `Louis`
for character in name:
    # Each iteration print a character
    print(character)

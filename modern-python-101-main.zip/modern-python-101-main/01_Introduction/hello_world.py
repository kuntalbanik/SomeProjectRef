# This is how you create a comment

# Print 'Hello, World!' to the terminal.
print("Hello, World!")

# `print` is a built-in `function` provided by Python

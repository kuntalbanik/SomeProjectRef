import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChannelPartnerDashboardComponent } from './channel-partner-dashboard.component';

describe('ChannelPartnerDashboardComponent', () => {
  let component: ChannelPartnerDashboardComponent;
  let fixture: ComponentFixture<ChannelPartnerDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChannelPartnerDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChannelPartnerDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

package main

import "fmt"

func sliceMain() {
	//
	// Define slice and initialize
	//
	nums := []int{1, 2, 3}
	nums = append(nums, 4)
	fmt.Println(nums)

	//
	// Blank slice define
	//
	another_nums := []int{}
	another_nums = append(another_nums, 1, 2, 3)
	fmt.Println(another_nums)

	//
	// Internal magic in slice
	// 👉 slice reference type
	// 👉 একই memory শেয়ার করে
	//
	a := []int{10, 20, 30}
	b := a

	b[0] = 100
	fmt.Println(a, "\n", b)

	fmt.Println("=========================")
	//
	// Now
	// 	👉 append করার সময় Go দেখে:
	// পুরনো array-এ capacity আছে নাকি নেই
	// এই ক্ষেত্রে:
	// slice literal {100,20,30} সাধারণত
	// len = 3
	// cap = 3

	// 👉 capacity শেষ ❌
	// 👉 Go নতুন array বানায়

	// 📌 তাই:
	// b → নতুন array [100 20 30 40]
	// a → পুরনো array [100 20 30]
	//
	b = append(b, 40)
	fmt.Println(b)
	fmt.Println(a)

	//
	// Slice length & capacity (Professional level)
	//
	// 	👉 capacity আগে থেকে দিলে:
	// memory efficient
	// performance ভালো
	//
	nums_new := make([]int, 0, 5)
	fmt.Println(len(nums_new)) // 0
	fmt.Println(cap(nums_new)) // 5

	nums_new = append(nums_new, 1, 2, 3)
	nums_new2 := nums_new
	nums_new2 = append(nums_new2, 4)
	fmt.Println(nums_new)
	fmt.Println(nums_new2)

	// Output
	// [1 2 3]
	// [1,2,3,4]
}

func main() {
	sliceMain()
}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReLoginDialogComponent } from './re-login-dialog.component';

describe('ReLoginDialogComponent', () => {
  let component: ReLoginDialogComponent;
  let fixture: ComponentFixture<ReLoginDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReLoginDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReLoginDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

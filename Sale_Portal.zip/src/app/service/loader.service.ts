import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoaderService {

  showLoader$: Subject<any> = new Subject<any>();
  

  constructor() { }

  display = (value: boolean) => {
    return this.showLoader$.next({display: value});
  }

}

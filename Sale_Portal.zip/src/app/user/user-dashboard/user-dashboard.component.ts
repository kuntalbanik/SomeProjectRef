import { Component, OnInit } from '@angular/core';
import { UserDetailsService } from '../../service/user-details/user-details.service';
import { Observable, Subject } from 'rxjs';

@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.css']
})
export class UserDashboardComponent implements OnInit {

  loggedInUserDetails$: Observable<any> = this.userDetailsService.getLoggedInUserDetails();
  userDetails: any = {};

  constructor(
  	private userDetailsService: UserDetailsService,
  	) { }

  ngOnInit(): void {
  }

  setUserDetails = (userDetails) => {
    this.userDetails = userDetails;    
  }

}

package main

func arrayMain() {
	var arr [3]int // 3 interger, size fixed
	arr[0] = 0
	arr[1] = 0
	arr[2] = 0

}

package main

import "fmt"

type bot interface {
	getGreeting() string
}

type englishBot struct{}

type spanishBot struct{}

func main() {
	eb := englishBot{}
	sb := spanishBot{}

	printGreeting(eb)
	printGreeting(sb)
}

func printGreeting(b bot) {
	fmt.Println(b.getGreeting())
}

//
// OLD Code
//
// func printGreeting(eb englishBot) {
// 	fmt.Println(eb.getGreeting())
// }

// func printGreeting(sb spanishBot) {
// 	fmt.Println(sb.getGreeting())
// }

func (englishBot) getGreeting() string {
	// Very custom logic for generating an english greeting
	//
	// ***Note : If we don't use receiver variable, then not
	// need to be assign it

	return "Hi There!"
}

func (spanishBot) getGreeting() string {
	// Very custom logic for generating and Spanish greeting

	return "Hola!"
}

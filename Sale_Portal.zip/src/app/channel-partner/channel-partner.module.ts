import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ChannelPartnerRoutingModule } from './channel-partner-routing.module';
import { ChannelPartnerDashboardComponent } from './channel-partner-dashboard/channel-partner-dashboard.component';


@NgModule({
  declarations: [ChannelPartnerDashboardComponent],
  imports: [
    CommonModule,
    ChannelPartnerRoutingModule
  ]
})
export class ChannelPartnerModule { }

package main

import (
	"fmt"
	"math/rand"
	"os"
	"strings"
	"time"
)

// Create a new type of deck
// which is a slice of strings
type deck []string

// Create a new slice of
// deck type and append in to cards
// ...
func newDeck() deck {
	cards := deck{}

	cardSuits := []string{"Spades", "Diamonds", "Hearts", "Clubs"}
	cardValues := []string{"Ace", "Two", "Three", "Four"}

	for _, suit := range cardSuits {
		for _, value := range cardValues {
			cards = append(cards, value+" of "+suit)
		}
	}

	return cards
}

// It's called receiver function
// or method
// ...
func (d deck) print() {
	for i, card := range d {
		// 'd' is similar like 'self' or 'this' in OOPS languages
		fmt.Println(i, card)
	}
}

// Return deal details
// after slicing it
// ...
func deal(d deck, handSize int) (deck, deck) {
	return d[:handSize], d[handSize:]
}

// Convert to byte slice to string
// ...
func (d deck) toString() string {
	return strings.Join([]string(d), ",")
}

// Data save to file
// ...
func (d deck) saveToFile(filename string) error {
	return os.WriteFile(filename, []byte(d.toString()), 0644)
}

// Get deck from file
// ...
func newDeckFromFile(filename string) deck {
	bs, err := os.ReadFile(filename)
	if err != nil {
		// Option #1 - log the error and return a call to newDeck()
		// Option #2 - log the error and entirely quit the program
		fmt.Println("Error : ", err)
		os.Exit(1)
	}
	s := strings.Split(string(bs), ",")
	return deck(s)
}

// Suffle cards
// ...
func (d deck) suffle() {

	// Generate random number
	//
	source := rand.NewSource(time.Now().UnixNano())
	r := rand.New(source)

	for i := range d {
		newPosition := r.Intn(len(d) - 1)
		// fmt.Println(rand.Intn(len(d) - 1))

		d[i], d[newPosition] = d[newPosition], d[i]
	}
}

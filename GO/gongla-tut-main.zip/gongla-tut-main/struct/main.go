package main

import "fmt"

type contactInfo struct {
	email   string
	zipCode int
}

type person struct {
	firstName string
	lastName  string
	contactInfo
}

func main() {

	// One way of declaration

	alex := person{
		firstName: "Alex",
		lastName:  "Laddfe",
		contactInfo: contactInfo{
			email:   "alex@example.com",
			zipCode: 889777,
		},
	}
	alex.print()

	// Another way of declaration

	var john person
	john.firstName = "John"
	john.lastName = "Millar"
	john.contactInfo.email = "john@abc.com"
	john.contactInfo.zipCode = 8989778

	// Type of *person, or a pointer to a person
	// johnPointer := &john
	// johnPointer.updateName("Kuntal")
	//

	// Type of person
	// Golang shortcut
	// Go will automatically converts -> 'person' type to 'pointer to person'
	john.updateName("Kuntal")

	john.print()
}

// Receiver function or method of structure 'person'
// ...
func (p person) print() {
	fmt.Println(p)
	fmt.Printf("%+v \n", p)
}

// Update name Receiver / Method
// ...
func (p *person) updateName(newFirstName string) {
	p.firstName = newFirstName
}

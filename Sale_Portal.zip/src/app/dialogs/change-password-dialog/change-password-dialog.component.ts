import { Component, OnInit, Inject, OnDestroy } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CustomValidators } from 'src/app/shared/custom.validator';
import { LoaderService } from 'src/app/service/loader.service';
import { UserDetailsService } from 'src/app/service/user-details/user-details.service';

@Component({
  selector: 'app-change-password-dialog',
  templateUrl: './change-password-dialog.component.html',
  styleUrls: ['./change-password-dialog.component.css']
})
export class ChangePasswordDialogComponent implements OnInit, OnDestroy {
	unsubscribeSubscription$: Subject<boolean> = new Subject<boolean>();
	passwordMinLength: number = 8;
	changePasswordForm: FormGroup;
	backEndError: string = "";

  constructor(
  	public dialogRef: MatDialogRef<ChangePasswordDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private fb: FormBuilder,
    private loaderService: LoaderService,    
    private userDetailsService: UserDetailsService,) { }

  ngOnInit(): void {
  	this.changePasswordForm = this.fb.group({
  		currentPassword: ['', [Validators.required, Validators.minLength(this.passwordMinLength),
  		 CustomValidators.passwordPatternCheck()]],
  		newPassword: ['', [Validators.required, Validators.minLength(this.passwordMinLength),
  		 CustomValidators.passwordPatternCheck(), CustomValidators.newPasswordCheck('currentPassword')]],
  	});
  }
  ngOnDestroy(): void {
    this.unsubscribeSubscription$.next(true);
    this.unsubscribeSubscription$.unsubscribe();
  }

  get currentPassword() {
    return this.changePasswordForm.get('currentPassword');
  }
  get newPassword() {
    return this.changePasswordForm.get('newPassword');
  }


  changePassword = () => {
  	if(this.changePasswordForm.valid) {
  		this.userDetailsService.changePassword(this.currentPassword.value, this.newPassword.value)
  		.pipe(takeUntil(this.unsubscribeSubscription$))
  		.subscribe(
  			(data) => {
  				console.log(data)
  				if(data == "success") this.dialogRef.close('success');
  				else this.backEndError = "Network issue, please try again later";
  			},
  			(error) => {
				console.log(error);
				if(this.userDetailsService.isEmpty(error.error))
					this.backEndError = "Network issue, please try again later";
				else{
					this.backEndError = error.error.old_password[0] || "Network issue, please try again later";
				}
  			},
  			);
  	}  	
  }

}

import { Injectable } from '@angular/core';
import { UserDetailsService } from 'src/app/service/user-details/user-details.service';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError, Subject, pairs } from 'rxjs';
import { catchError, map, delay } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class LoginRegistrationService {

  apiLink = {
    "package": "./assets/data/sale-package.json",
    "country": "./assets/data/country.json",
    "states-and-districts": "./assets/data/states-and-districts.json",
    "login": "https://accountp.herokuapp.com/api/auth/login/",
    "registration": "https://accountp.herokuapp.com/api/auth/register/"
  };

  unsubscribeRegistration$ = new Subject();

  constructor(private userDetailsService: UserDetailsService, private http: HttpClient) { }

  logInAuthentication = (userDetails: any) => {
    if(userDetails === null){
      return null;
    }
    let apiLink = this.getAPILink("login");
    return this.http.post(apiLink, userDetails).pipe(      
      map((data) => {
        let isLoggedIn = !this.userDetailsService.isEmpty(data["user"]);
        this.userDetailsService.setLoggedInTokenDetails(
          isLoggedIn ? data["token"] : "",
          (1000*60*60)
        );
        this.userDetailsService.setLoggedinUserDerails(
          isLoggedIn ? data["user"] : {}
        );
        let role = data["user"].role.length === 0 ? 'user': data["user"].role;        
        return { success: isLoggedIn, res: `dashboard/${role}` };
      }),
      catchError((error) => {
        console.log(error);
        let errorRes =  typeof (error.error) == "object" ?
         error.error:"Network issue, please try after sometime";
          // pairs((error.error)).pipe(
          //   map(([err, val]) => { return { success: false, res: val[0] } }),
          //   catchError(() => throwError("Network issue, please try after sometime"))
          // ) :
          // throwError("Network issue, please try after sometime")
          return throwError(errorRes);
      }),      
    );
  }

  registration = (userFormDetails) => {
    delete userFormDetails["confirmPassword"];
    let apiLink = this.getAPILink("registration");
    return this.http.post(apiLink, userFormDetails).pipe(
      map((data) => {
        let isRegistered = !this.userDetailsService.isEmpty(data["user"]);
        this.userDetailsService.setLoggedInTokenDetails(
          isRegistered ? data["token"] : "",
          (1000*60*60)
        );
        this.userDetailsService.setLoggedinUserDerails(
          isRegistered ? data["user"] : {}
        );
        let role = data["user"].role.length === 0 ? 'user': data["user"].role;        
        return { success: isRegistered, res: `dashboard/${role}` };

      }),
      catchError((error) => {
        return typeof (error.error) == "object" ?
          pairs((error.error)).pipe(
            map(([err, val]) => { return { success: false, res: val[0] } }),
            catchError(() => throwError("Network issue, please try after sometime"))
          ) :
          throwError("Network issue, please try after sometime")
      })
    );
  }

  getCountryDetails = () => {
    let apiLink = this.getAPILink('country');
    return this.http.get(apiLink).pipe(map((data) => {
      return data["countries"] || [];
    }));
  }
  getStateDetails = () => {
    let apiLink = this.getAPILink('states-and-districts');
    return this.http.get(apiLink).pipe(
      map((data) => {
        return data["states"].map((data) => data["state"] || "") || [];
      })
    );
  }
  getDistrictDetails = (stateName: string): Observable<Object> => {
    if (stateName.length === 0) {
      return null;
    };
    let apiLink = this.getAPILink('states-and-districts');
    return this.http.get(apiLink).pipe(
      map((data) => {
        return data["states"].filter((data) => data["state"] === stateName).flatMap(data => data["districts"]);
      })
    );
  }
  getPackageDetails = () => {
    let apiLink = this.getAPILink('package');
    return this.http.get(apiLink);
  }

  getAPILink = (apiName) => {
    return this.apiLink[apiName];
  }

}

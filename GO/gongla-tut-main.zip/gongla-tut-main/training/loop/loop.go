package main

import "fmt"

func main() {

	// For loop like python for loop
	//
	// for i in range(5):
	// print(i)
	//
	for i := range 5 {
		fmt.Println("i - ", i)
	}

	//
	// like python while loop
	//
	// while x < 5:
	// x += 1
	//
	loopx := 0
	for loopx < 5 {
		fmt.Println("loopx - ", loopx)
		loopx++
	}

	//
	// Find even numbers
	//
	for i := 1; i <= 5; i++ {
		if i%2 == 0 {
			fmt.Println(i)
		}
	}
	// Output : 2 4
}

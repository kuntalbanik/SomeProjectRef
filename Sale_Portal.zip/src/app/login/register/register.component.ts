import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { LoginRegistrationService } from '../service/login-registration.service';
import { CustomValidators } from 'src/app/shared/custom.validator';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { OnlyTextDialogComponent } from 'src/app/dialogs/only-text-dialog/only-text-dialog.component';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],  
})
export class RegisterComponent implements OnInit, OnDestroy {

  registrationForm: FormGroup;
  passwordMinLength: number = 8;
  packageDetails$: Observable<Object>;
  countryDetails$: Observable<Object>;
  stateDetails$: Observable<Object>;
  districtDetails$: Observable<Object>;
  registrationStatus: boolean = false;
  afterRegistrationNavPath: string = "";
  errorFromBackend: string = "";
  unsubscribeSubscriptions$: Subject<boolean> = new Subject<boolean>();

  constructor(
    private fb: FormBuilder,
    private loginRegistrationService: LoginRegistrationService,
    private router: Router,
    public dialog: MatDialog,    
  ) { }

  ngOnInit() {
    this.registrationForm = this.fb.group({
      fullName: ['', [Validators.required]],
      company: ['', [Validators.required]],
      country: ['', [Validators.required]],
      state: ['', [Validators.required]],
      district: ['', [Validators.required]],
      pan: ['', [Validators.required]],
      package: ['', [Validators.required]],
      emailId: ['', [Validators.required, CustomValidators.emailOrPhoneNumber('emailId')]],
      contact: ['', [Validators.required, CustomValidators.emailOrPhoneNumber('phoneNumber')]],
      password: ['', [Validators.required, Validators.minLength(this.passwordMinLength), CustomValidators.passwordPatternCheck()]],
      confirmPassword: ['', [Validators.required, CustomValidators.confirmPasswordCheck('password')]],
    });

    this.countryDetails$ = this.loginRegistrationService.getCountryDetails();
    this.stateDetails$ = this.loginRegistrationService.getStateDetails();
    this.districtDetails$ = this.loginRegistrationService.getDistrictDetails(this.state.value);
    this.packageDetails$ = this.loginRegistrationService.getPackageDetails();
  }

  ngOnDestroy() {
    this.unsubscribeSubscriptions$.next(true);
    this.unsubscribeSubscriptions$.unsubscribe();
  }

  get fullName() {
    return this.registrationForm.get('fullName');
  }
  get company() {
    return this.registrationForm.get('company');
  }
  get country() {
    return this.registrationForm.get('country');
  }
  get state() {
    return this.registrationForm.get('state');
  }
  get district() {
    return this.registrationForm.get('district');
  }
  get pan() {
    return this.registrationForm.get('pan');
  }
  get package() {
    return this.registrationForm.get('package');
  }
  get emailId() {
    return this.registrationForm.get('emailId');
  }
  get contact() {
    return this.registrationForm.get('contact');
  }
  get password() {
    return this.registrationForm.get('password');
  }
  get confirmPassword() {
    return this.registrationForm.get('confirmPassword');
  }

  getDistrictDetails = () => {
    this.districtDetails$ = this.loginRegistrationService.getDistrictDetails(this.state.value);
  }

  registerUser = () => {
    if (this.registrationForm.valid) {
      this.errorFromBackend = "";
      this.loginRegistrationService.registration(this.registrationForm.value)
        .pipe(
          takeUntil(this.unsubscribeSubscriptions$)
        )
        .subscribe((data) => {
          if (data.success) {
            let msg = "";
            this.registrationStatus = data.success;                  
            if(data.res.length > 0){
              this.afterRegistrationNavPath = data.res;
              msg = "Registration Successfull";
            } else{
              msg = "Network issue, please try after sometime";
              this.registrationStatus = false;
            }
            this.openOnlyTextDialog(msg);
          } else {
            this.errorFromBackend = `${this.errorFromBackend}\n${data.res}`;
            if(this.errorFromBackend === "undefined" || this.errorFromBackend === "null"){
              this.errorFromBackend = "Network issue, please try after sometime";
            }
          }
        }, (error) => {
          this.errorFromBackend += error;
        })
    }
  }

  openOnlyTextDialog = (msg) => {
    const unsubscribeDialog$ = new Subject();
    const dialogRef = this.dialog.open(OnlyTextDialogComponent, {
      width: '250px',
      data: { msg: msg }
    });

    dialogRef.afterClosed().pipe(
      takeUntil(unsubscribeDialog$)
    ).subscribe(result => {
      if(this.registrationStatus){
        console.log(this.afterRegistrationNavPath)
        this.router.navigate([this.afterRegistrationNavPath]);
      }
      unsubscribeDialog$.next(true);
      unsubscribeDialog$.unsubscribe();      
    });
  }


}

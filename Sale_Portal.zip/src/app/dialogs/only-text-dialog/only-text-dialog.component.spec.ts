import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnlyTextDialogComponent } from './only-text-dialog.component';

describe('OnlyTextDialogComponent', () => {
  let component: OnlyTextDialogComponent;
  let fixture: ComponentFixture<OnlyTextDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnlyTextDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnlyTextDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

<?php

namespace App\Http\Controllers;

use App\Models\Task;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class TaskController extends Controller
{
    //

    public $timestamps = false;

    
    // dashboard function
    function dashboard(){


        if (Auth::check()) {
            // Get the authenticated owner name
            $owner = Auth::user()->email;
            // $latestTasks = $user->tasks()->latest()->take(5)->get();
            // $latestTasks = Task::orderBy('id', 'desc')->take(5)->get();
            // Query the posts table using the Post model
            
            $latestTasks = Task::where('owner', $owner) // Filter by logged-in user
                         ->where('status', 'Open')   // Add condition for 'open' status
                         ->latest()                  // Order results by `created_at` DESC
                         ->take(2)                   // Take the first 5 results
                         ->get();   
            
        } else {
            $latestTasks = collect();
        }
        // echo $latestTasks;
        return view('dashboard', ['tasks' => $latestTasks]);
    }





    // Add Tasks & save data in DB
    function addTasks(Request $request)
    {

        // Get the authenticated user's email
        $owner = Auth::user()->email;


        // Get current time stamp
        $currentTime = Carbon::now();

        $currentLocation = $request->loc;

        $address = "Dummy address";

        // echo $owner . $currentTime . $currentLocation;


        $outputResult = Task::insert([
            'owner' => $owner,
            'task_name' => $request->task_name,
            'visit_purpose' => $request->visit_purpose,
            'ref_info' => $request->ref_info,
            // 'created_at' => $currentTime,
            'start_lng_lat' => $currentLocation,
            'start_addr' => $address,
            'status' => "Open",
        ]);

        if ($outputResult) {
            // echo $outputResult;
            // echo "Data inserted";
            return redirect('tasks');
        } else {
            echo "Data not inserted";
            // echo "Student add called";
        }
    }

    // Get all tasks from database
    function getTasks()
    {

        // Return function output from   Model
        // $data = new Task;
        $owner = Auth::user()->email;
        $task_data = Task::where('owner', $owner)
                    // ->orderBy('created_at', 'desc')
                    ->orderByRaw("CASE WHEN status = 'open' THEN 1 ELSE 2 END")
                    ->latest()
                    ->get();
 

        return view('task-list', ['tasks' => $task_data]);
    }



    // Get single task details
    function getSingleTask(Request $request)
    {

        $task_data = Task::where('id', $request->id)->get();

        return view('task', ['tasks' => $task_data]);
    }


    // Update task
    function updateTask(Request $request)
    {

        // Get the authenticated user's email
        $owner = Auth::user()->email;


        // Get current time stamp
        $currentTime = Carbon::now();

        $currentLocation = $request->loc;

        $address = "Dummy address";

        $createdAt = Task::where('id', $request->id)
                    ->value('created_at');
                    // ->get();

        // Save current login timestamp
        // $owner = Auth::user()->email;
        if($request->status == "Closed"){
            $out1 = Task::where('id', $request->id)->update([
                'status' => $request->status, 
                'end_lng_lat' => $currentLocation, 
                'end_addr' => $address, 
                'start_at' => $createdAt
            ]);

            if($out1) {
                return redirect('tasks');
            }
        }
        else
            return redirect('tasks');

        // echo $request->id;
    }



    // public function showDuration()
    // {
    //     // Example data from your database (or fetched via a query)
    //     $record = Task::first(); // Or use find(), where(), etc.

    //     if ($record) {
    //         // Eloquent automatically casts 'start' and 'end' to Carbon objects
    //         $startTime = $record->start;
    //         $endTime = $record->end;

    //         // Calculate the difference in minutes
    //         $totalMinutes = $startTime->diffInMinutes($endTime);

    //         // Convert total minutes into hours and remaining minutes
    //         $hours = floor($totalMinutes / 60);
    //         $minutes = $totalMinutes % 60;

    //         $duration = sprintf('%d hours and %d minutes', $hours, $minutes);
    //     } else {
    //         $duration = 'No record found.';
    //     }

    //     return view('your.view', compact('duration'));
    // }

}

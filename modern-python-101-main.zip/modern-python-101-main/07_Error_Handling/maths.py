def add(x: int, y: int) -> None:
    print(x y)
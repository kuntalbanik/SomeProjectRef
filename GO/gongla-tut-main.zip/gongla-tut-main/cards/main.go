package main

func main() {
	cards := newDeck()
	cards.suffle()
	// cards := newDeckFromFile("my_cards2")
	cards.print()

	// cards.saveToFile("my_cards")

	// fmt.Println(cards.toString())

	// cards = append(cards, "Six of Sprades")
	// hand, remainingCards := deal(cards, 5)
	// hand.print()
	// remainingCards.print()
	// cards.print()
}

// func newCard() string {
// 	return "Five of Diamonds"
// }

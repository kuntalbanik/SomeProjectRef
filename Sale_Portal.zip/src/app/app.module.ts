import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { UserDetailsService } from './service/user-details/user-details.service';
import { AuthGuardService } from './service/auth-guard.service';
import { LoaderInterceptor } from './interceptors/loader.interceptor';
import { LoaderService } from './service/loader.service';
import { OnlyTextDialogComponent } from 'src/app/dialogs/only-text-dialog/only-text-dialog.component';



@NgModule({
  declarations: [
    AppComponent,
    OnlyTextDialogComponent        
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,    
    BrowserAnimationsModule,
    MatProgressSpinnerModule,
    MatButtonModule,
    MatDialogModule,
  ],
  providers: [
    LoaderService,
    { provide: HTTP_INTERCEPTORS, useClass: LoaderInterceptor, multi: true },
    UserDetailsService, 
    AuthGuardService,
  ],
  bootstrap: [AppComponent],
})
export class AppModule { }

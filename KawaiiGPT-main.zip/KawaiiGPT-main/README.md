## KawaiiGPT

<div align="center">
    <img src="kawaii.svg" width="50%" height="300%" />
</div>

- THIS TOOLS HAS BEEN CLOSED FROM ADMIN, AND IT'S NOW OPEN SOURCE, USE IT FOR LEARNING!.
> Forum: [Telegram](https://t.me/kawaiigpt_official)

## Use (Linux Distro)
---
``` bash
apt-get update && apt-get upgrade (if not updated and upgraded)
apt install python3 && apt install python3-pip
apt install git
git clone https://github.com/MrSanZz/KawaiiGPT
cd KawaiiGPT
python3 install.py
python3 kawai.py
```

## Use (Termux)

``` bash
pkg update && pkg upgrade (if not updated and upgraded)
pkg install python3
pkg install git
git clone https://github.com/MrSanZz/KawaiiGPT
cd KawaiiGPT
python3 install.py
python3 kawai.py
```
---
- *Have fun! (support me with star ⭐ !!)*

## Information

KawaiiGPT uses a **reverse-engineered LLM API wrapper** original agents at:

> [https://github.com/pollinations/pollinations](https://github.com/pollinations/pollinations)

For the rest Back-End, it uses a server to serve other obtainable LLM such as DeepSeek, Gemini, or Kimi-K2

## ⚠️ =Disclaimer=
>
> * This project was made to be **fun**!
> * All risks or consequences that you have done are **your own responsibility**.
> * Changing or selling this tools is prohibited and not allowed!. ⚠
> * Using a **prepared** model, **not** a fine-tuned model!
> * All LLM here uses a prompt injection! (jailbreak has been written on help-menu)
> * This is KawaiiGPT, not WormGPT, **made to be fun or companies!**
> * WormGPT tag only **used for jailbreaked model**
---

# QnA
``` plain
"Why is it obfuscated?"

Me: Okay, many people asking this question, the reason why i obfuscate the
    code is because I want to avoid recoding and renaming which ends up 
    selling KawaiiGPT tools under my name and claiming that it belongs to them

"This is obviously a virus or a RAT"

Me: Seriously, i'm enough with this question over time. No, there is no RAT, Spyware,
    Malware, Ransom, etc. Why would i do that? because it's free and obfuscated
    doesn't mean i wanna trap you all, **i wouldn't**. If that wasn't from me
    don't run it or you would fall in a trap. 

"But why is it obfuscated?"

Me: Like what i said earlier, "I want to avoid recoding and renaming which ends up 
    selling KawaiiGPT tools under my name and claiming that it belongs to them".
    Please understand that i wouldn't put a malicious code into my tools/code,
    if somebody said "KawaiiGPT has a virus!!" in Telegram or other please don't
    trust it, maybe they just want to bring down my name or they got the wrong KawaiiGPT
    that is not from me.
```

## Conclusion:
---
I never put any malicious code or even malicious software into my code/tools
if it's obfuscated that means I just want to avoid recoding and selling
--

> Best regards, ```MrSanZz+Shoukaku07+FlamabyX5```
Made with 🔥

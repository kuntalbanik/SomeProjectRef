# -----------------------------------------------------------------
# Louis is going for a party, he has got balloons, crackers & hats
# -----------------------------------------------------------------

# Declaring a new variable called as `box`
box = "Balloons"
print(box)  # prints -> Balloons

# Louis changes his mind, he now wants to pack crackers instead
box = "Crackers"
print(box)  # prints -> Crackers

# Louis changes his mind yet again, now wants to pack hats
box = "Hats"
print(box)  # prints -> Hats

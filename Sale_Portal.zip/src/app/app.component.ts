import { Component, ChangeDetectionStrategy, OnInit, OnDestroy, HostListener } from '@angular/core';
import { Subject } from 'rxjs';
import { LoaderService } from './service/loader.service';
import { UserDetailsService } from './service/user-details/user-details.service';
import { Router, NavigationStart, NavigationEnd, NavigationCancel, NavigationError } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AppComponent implements OnInit, OnDestroy{
  title = 'sale-portal';
  color = 'accent';
  mode = 'indeterminate';
  strokeWidth = 5;

  showLoader$: Subject<any> = this.loaderService.showLoader$;
  routerEventSubscription: any;

  constructor(
    private loaderService: LoaderService,
    private userDetailsService: UserDetailsService,
    private router: Router
  ) {
    this.routerEventSubscription = router.events.subscribe((routerEvent) => {
      this.checkRouterEvent(routerEvent);
    });
  }

  ngOnInit(){  
  }


@HostListener('window:beforeunload')
  ngOnDestroy() {
    this.userDetailsService.setLoggedInTokenToStorage();
    this.routerEventSubscription.unsubscribe();
  }

  checkRouterEvent = (routerEvent) => {
    if(routerEvent instanceof NavigationStart){
      this.loaderService.display(true);
    }
    if(
      routerEvent instanceof NavigationEnd ||
      routerEvent instanceof NavigationCancel ||
      routerEvent instanceof NavigationError 
    ){
      this.loaderService.display(false);
    }
  }

}

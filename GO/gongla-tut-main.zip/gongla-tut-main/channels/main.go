package main

import (
	"fmt"
	"net/http"
	"time"
)

func main() {

	links := []string{
		"http://google.com",
		"http://facebook.com",
		"http://stackoverflow.com",
		"http://golang.org",
		"http://amazon.com",
	}

	// Creating channel
	c := make(chan string)

	for _, link := range links {

		// passing channel to the function
		go checkLink(link, c)
	}
	// for i := 0; i < len(links); i++ {
	// 	// fmt.Println(<-c)
	// 	checkLink(<-c)
	// }

	for l := range c {
		go func() {
			time.Sleep(20 * time.Second)
			checkLink(l, c)
		}()
	}

	// for {
	// 	checkLink(<-c, c)
	// }
}

func checkLink(link string, c chan string) {
	_, err := http.Get(link)
	if err != nil {
		fmt.Println(link, "might be down!")
		c <- link
		return
	}
	fmt.Println(link, "is up!")
	c <- link
}

const express = require('express');
const path = require('path');
const app = express();

// Serve static files....
app.use(express.static('dist/sale-portal'));
// app.use(express.static(__dirname + '/dist/sale-portal'));

// Send all requests to index.html
app.get('/*', function(req, res) {
  res.sendFile(path.join('dist/sale-portal/index.html'));
});

// default Heroku PORT
app.listen(process.env.PORT || 3000);
console.log('server listening on port 3000');
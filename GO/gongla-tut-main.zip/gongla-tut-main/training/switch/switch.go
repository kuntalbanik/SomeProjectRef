package main

import "fmt"

func main() {

	// Simple switch - case
	day := 0

	switch day {
	case 5:
		fmt.Println("Friday")
	case 1:
		fmt.Println("Monday")
	case 0:
		fmt.Println("Sunday")
	default:
		fmt.Println("Others")
	}

	//
	// switch - case week days with condition
	//

	conditionDay := 1

	switch {
	case conditionDay > 0 && conditionDay < 6:
		fmt.Println("Week Days")
	case conditionDay == 0 || conditionDay == 6:
		fmt.Println("Holiday")
	default:
		fmt.Println("Others")
	}

	//
	// switch - case with condition
	// specific condition should be on top
	//
	//
	x := 15

	switch {
	case x%3 == 0 && x%5 == 0:
		fmt.Println("FizzBuzz")
	case x%3 == 0:
		fmt.Println("Fizz")
	case x%5 == 0:
		fmt.Println("Buzz")
	default:
		fmt.Println(x)
	}

	// Output : FizzBuzz ( 15 divisable by 3 & 5 and reminder 0)
}

import { AbstractControl } from '@angular/forms';

export class CustomValidators {

  static emailOrPhoneNumber(validate) {
    return (control: AbstractControl): { [key: string]: any } | null => {
      const value: string = control.value;
      const emailPattern = new RegExp('^([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5})$|^[2-9]\d{2}\d{3}\d{4}$');
      const phNumberPattern = new RegExp('^[6-9][0-9]{9}$');
      let validationCondition = false; 

      switch(validate){
        case 'emailId': validationCondition = emailPattern.test(value);
        break;
        case 'phoneNumber': validationCondition = phNumberPattern.test(value);
        break;
        case 'both': validationCondition = emailPattern.test(value) || phNumberPattern.test(value);
        break;
        default: validationCondition = false;
      }

      if (value === '' || validationCondition) {
        return null;
      } else {
        return { emailOrPhoneNumber: true };
      }
    };
  }

  static passwordPatternCheck = () => {
    return (control: AbstractControl): { [key: string]: any } | null => {
      const value: string = control.value;
      const passwordPattern = new RegExp('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})');      
      if (value === '' || passwordPattern.test(value) ) {
        return null;
      } else {
        return { passwordPatternCheck: true };
      }
    };
  }
  static confirmPasswordCheck = (controlName) => {
    return (control: AbstractControl): { [key: string]: any } | null => {
      let controlToCompare: AbstractControl = null;
      let isMatched = { passwordMatch: true };
      if(control.parent !== undefined){
        controlToCompare = control.parent.get(controlName);
      }      
      
      if(controlToCompare !== null){
        if (control.value === '' || (controlToCompare.value === control.value)) {
          isMatched = null;
        } 
      }   

      return isMatched;
    };
  };
  static newPasswordCheck = (controlName) => {
    return (control: AbstractControl): { [key: string]: any } | null => {
      let controlToCompare: AbstractControl = null;
      let isMatched = { currentPasswordMatch: true };
      if(control.parent !== undefined){
        controlToCompare = control.parent.get(controlName);
      }      
      
      if(controlToCompare !== null){
        if (control.value === '' || (controlToCompare.value !== control.value)) {
          isMatched = null;
        } 
      }   

      return isMatched;
    };
  };


}
package main

import "fmt"

func main() {

	// If else example
	num := 5

	if num > 0 {
		fmt.Println("Possitive")
	} else if num < 0 {
		fmt.Println("Negative")
	} else {
		fmt.Println("Zero")
	}

	// Another real life example
	balance := 1000
	withdraw := 1500

	if withdraw <= balance {
		fmt.Println("Withdraw allowed")
	} else {
		fmt.Println("Insufficient balance")
	}

}
